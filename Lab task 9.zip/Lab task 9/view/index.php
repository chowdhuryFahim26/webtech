<!DOCTYPE html>
<html>
<head>
    <title>Home Page</title>
</head>
<body>
        <center>
        <table border="1" width="1000px">
            <tr>
                   <td>
                    <table width="1200px">
                        <tr>
                            <td align="right">
                                <h1><b>TOUR AND TRAVEL COMPANY</b></h1>
                            </td>
                            <td align="Right">

                                <a href="index.php">Home</a> 
                                <a href="Login.php">Login</a> 
                                <a href="Registration.php">Registration</a>
                        </td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr>
                <td colspan="2" height="200px" align="center">
                    
                   <h1> <b>Welcome To Adventure Life Tours<b> </h1>
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <center>
                    Explore The World
                    </center>
                </td>
            </tr>
         </table>
    </center>
</body>
</html>