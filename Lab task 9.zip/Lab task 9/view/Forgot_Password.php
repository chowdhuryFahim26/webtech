<!DOCTYPE html>
<html>
<head>
  <title>FORGOT PASSWORD</title>
</head>
<body>
	<!--<form method="post" action="../controller/forgotpasswordCheck.php">-->
			<center>
    <table border="1" width="1500px">
	    <tr>
            <td>
                <table width="1000px">
                    <tr>
						<td align="Left">
                <h><b>MyCompany</b></h>
            </td>
            <td align="Right">
                <a href="../index.php">Home</a> 
                <a href="Login.php">Login</a> 
                <a href="Registration.php">Registration</a>
            </td>
                    </tr>
                    </table>
            </td>
        </tr>        
        <tr>
            <td colspan="2">
			<fieldset>
			<legend>FORGOT PASSWORD</legend>
			<table>
				<tr>
					<td>Enter Email</td>
					<td><input type="email" name="email"></td>
				</tr>
                <tr>
                   <td colspan="2"><hr></td> 
                </tr>
				<tr>
					<td><input type="submit" name="submit" value="Submit"></td>
                </tr>
			</table>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <center>
                Copyright 2017
                </center>
            </td>
        </tr>
    </table>
    </center>
		
	</form>
</body>
</html>