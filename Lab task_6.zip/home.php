<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <table border="1" cellspacing="0" height="50px" width="100%">
        <tr>
            <td style="text-align: right;">
                <a href="">Home</a>
                <p style="display: inline;">|</p>
                <a href="">Login</a>
                <p style="display: inline;">|</p>
                <a href="registration.html">Registration</a>
            </td>
        </tr>
        </table>
        <table border="1" cellspacing="0" height="250px" width="100%">
        <tr>
            <td width="250px">
                <h1>Account</h1><hr>
                <ul>
                    <li>
                        <a href="dashboard.php">Dashboard</a>
                    </li>
                    <li>
                        <a href="">View Profile</a>
                    </li>
                    <li>
                        <a href="">Edit Profile</a>
                    </li>
                    <li>
                        <a href="">Change PRofile Picture</a>
                    </li>
                    <li>
                        <a href="">Change Password</a>
                    </li>
                    <li>
                        <a href="">Logout</a>
                    </li>
                </ul>
            </td>
            <td>
                <h1>Welcome Bob</h1>
                
            </td>
        </tr>
        </table>
        <table border="1" cellspacing="0" height="25px" width="100%">
        <tr>
            <td>
                <footer style="text-align: center;">Copyright © 2017</footer>
            </td>
        </tr>
    </table>
</body>
</html>