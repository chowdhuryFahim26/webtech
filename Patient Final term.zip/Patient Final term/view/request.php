<?php

?>

<html>
     
      <head>
          <title>Request for service</title>
      </head>>

      <body background="service.jpg">
      
      <h2><b>>Request for service</b></h2>

      <ul>
               <h3> <li> emergency service</li></h3>
               <h3> <li> home service </li></h3>
                <h3><li>Request for ambulance</li></h3>
                
            </ul>  
     
           
              
     </body>>

</html>
