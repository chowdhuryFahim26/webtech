<?php

?>

<html>
     
      <head>
          <title>Payment</title>
           <style>
            section{background-color: skyblue;
                text-align: center;
                font-size: 30px;}
               
          </style>

      </head>

      <body background="paymentImage.jpg">
      
      <h2><b>>For payment</b></h2>


      <ul>
               <h3> <li> Digital pay</li></h3>
              <h3>  <li> cash pay </li></h3>
                <h3><li>Pay later (in case of emergency)</li></h3>

                  <li>
                   <h3> <a href="dashboard.php " onclick="log()">Back</a> </h3> 

                </li>

                
            </ul>  
            <script>
              function log() {
             alert("Are You Sure you want to go ?");
             }


            </script>
     
           
              
     </body>

</html>
