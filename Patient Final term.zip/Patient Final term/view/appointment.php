<?php

?>

<html>
     
      <head>
          <title>Doctor appointment</title>
           <style>
            section{background-color: skyblue;
                text-align: center;
                font-size: 30px;}
               
          </style>
      </head>

      <body background="appointment.jpg">
      
     <h2> <b>Appointment</b></h2>
       <style>
            section{background-color: skyblue;
                text-align: center;
                font-size: 30px;}
               
          </style>

      <ul>
               <h3> <li> Call</li></h3>
                <h3><li> Online booking</li></h3>
                 <li>
                   <h3> <a href="dashboard.php " onclick="log()">Back</a> </h3> 

                </li>
                
            </ul>  
     
                   <script>
              function log() {
             alert("Are You Sure you want to go ?");
             }


            </script>
           
              
     </body>

</html>
