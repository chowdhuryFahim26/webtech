<?php

?>

<html>
     
      <head>
          <title>Review</title>>
      </head>>

      <body background="complain.jpg">
      
      <b>>can you please give a review: </b>

      <div>
      
      <label for ="massage"> </label><br>
      <textarea col="50" rows="20"></textarea>
     
      </div>

      <div>
      	   <input type="submit" value="Submit">
      	   <input type="reset" value="Reset">
      </div>
              
     </body>>

</html>
