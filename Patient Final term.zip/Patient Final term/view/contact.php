<?php

?>

<html>
     
      <head>
          <title>contact</title>
      </head>

      <body background="contact.jpg">
      
      <h2><b>For contact</b></h2>

      <ul>
                <h3><li> call us</li></h3>
                <h3><li> email </li></h3>
               
                
            </ul>  

            <ul>
              
                  <li>
                   <h3> <a href="dashboard.php " onclick="log()">Back</a> </h3> 

                </li>

                
            </ul>  
            <script>
              function log() {
             alert("Are You Sure you want to go ?");
             }


            </script>
     
           
              
     </body>>

</html>
