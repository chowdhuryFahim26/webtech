<?php

?>

<html>
     
      <head>
          <title>Doctor List</title>>
           <style>
            section{background-color: skyblue;
                text-align: center;
                font-size: 30px;}
                table {
                    text-align: center;
                    font-size: 25px;}
          </style>
      </head>>

      <body background="Dr list.jpg">
      
      
           <center> 
           <table border = "2">  
               <form align = "top-center" action="../view/Drlist.php" method ="post">   
           <tr width="500px">
                            <th colspan="6" width="200px" align="center"><h3>Doctors Information</h3></th>  
                            <tr width="500px">
                            <th >Name of doctors</th>
                            <th >Specialization</th>
                           
                        </tr>
                        </tr>
                        </tr>
                        <tr align="right">
                        
                        </tr>

            <tr>
                            <td align="center">Dr. Kamrul hasan</td>
                          
                            <td align="center">Cardiologist</td>
                           
                        </tr>
                        <tr>
                            <td align="center">Dr. shojib hasan</td>

                            <td align="center">Cardiologist</td>
                           
                            </tr>

                            <tr>
                            <td align="center">Dr. sourova das</td>
                          
                            <td align="center">Medicine</td>
                           
                        </tr>
                        <tr>
                            <td align="center">Dr. shimanto poddar</td>

                            <td align="center">Medicine</td>
                           
                            </tr>

                           <tr>
                            <td align="center">Dr. mehedi Hasan</td>
                          
                            <td align="center">Medicine</td>
                           
                        </tr>
                        <tr>
                            <td align="center">Dr. saikat ahmed</td>

                            <td align="center">Medicine</td>
                           
                            </tr>

                           <tr>
                            <td align="center">Dr. Abdur Rahman</td>
                          
                            <td align="center">Peditrician</td>
                           
                        </tr>
                        <tr>
                            <td align="center">Dr. Arafat Fuad</td>

                            <td align="center">Peditrician</td>
                           
                            </tr>
                             
                             <tr>
                            <td align="center">Dr. Zahida jabber</td>
                          
                            <td align="center">Gaeonocologist</td>
                           
                        </tr>
                        <tr>
                            <td align="center">Dr. fatima trina</td>

                            <td align="center">Gaeonocologist</td>
                           
                            </tr>
                  
         
 

           </table>
            </form>
           </center>
              
     </body>>

</html>

