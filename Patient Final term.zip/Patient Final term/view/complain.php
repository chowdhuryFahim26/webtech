<?php

?>

<html>
     
      <head>
          <title>complain</title>>
      </head>>

      <body background="complain.jpg">
      
      <h3><b>For any complain: </b></h3>

      <div>
      
      <label for ="massage"> </label><br>
      <textarea col="50" rows="20"></textarea>
     
      </div>

      <div>
      	   <input type="submit" value="Submit">
      	   <input type="reset" value="Reset">
      </div>

       <li>
                   <h3> <a href="dashboard.php " onclick="log()">Back</a> </h3> 

                </li>

                
           
            <script>
              function log() {
             alert("Are You Sure you want to go ?");
             }


            </script>
     
              
     </body>

</html>
